<html>
<head>
<title>Страница бана Minecraft</title>
</head>
<body>
    <h1>Страница бана Minecraft</h1>
    <form method="post" action="ban.php">
        <label for="username">Ник пользователя Minecraft:</label>
        <input type="text" name="username" id="username" required>



        <label for="reason">Причина бана:</label>
        <input type="text" name="reason" id="reason">



        <input type="submit" value="Отправить бан">
    </form>
</body>
</html>