<form method="GET" action="ban.php">
    <h2>Player</h2>
    <input name="player"></input>
    <h2>Reason</h2>
    <input name="reason"></input>
    <h2>Time</h2>
    <input name="time"></input>
    <button>Ban</button>