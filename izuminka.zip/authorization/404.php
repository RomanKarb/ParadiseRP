<?php
$url = $_GET['url'];
?>
<!DOCTYPE html>
<html>
<head>
 <title>Error 404 - Page not found</title>
</head>
<body>
 <h1>Error 404 - Page not found</h1>
 <p>The requested URL <strong><?php echo $url; ?></strong> was not found on this server.</p>
</body>
</html>