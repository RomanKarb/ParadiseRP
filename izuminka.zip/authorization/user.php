<form action="profile.php" method="post">
    <label for="username">Введите логин:</label>
    <input type="text" name="username">
    <input type="submit" value="Найти">
</form>