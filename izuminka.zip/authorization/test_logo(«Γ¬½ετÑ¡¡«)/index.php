<!-- Форма для загрузки картинки -->
<form enctype="multipart/form-data" action="reg.php" method="post">
    <input type="file" name="image" accept="image/*">
    <input type="submit" value="Загрузить">
</form>

<!-- Предпросмотр картинки -->
<div id="preview"></div>