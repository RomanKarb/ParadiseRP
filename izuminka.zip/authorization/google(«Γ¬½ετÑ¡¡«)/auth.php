<?php
// Подключение библиотеки Google API Client
require_once 'vendor/autoload.php';

// Устанавливаем конфигурацию для клиента
$client = new Google_Client();
$client->setClientId('277100920120-uaudhpkjo2l3qiks0r9b39n672qepesl.apps.googleusercontent.com'); // Установите ваш Client ID
$client->setClientSecret('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'); // Установите ваш Client Secret
$client->setRedirectUri('http://www.izuminka.com/authorization/google/auth.php'); // Установите вашу Redirect URI
$client->addScope('email');
$client->addScope('profile');

if (!isset($_GET['code'])) {
    $authUrl = $client->createAuthUrl();
    header("Location: $authUrl");
    exit;
}

try {
    $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $accessToken = $client->getAccessToken();

    $service = new Google_Service_Oauth2($client);
    $userData = $service->userinfo->get();

    $name = $userData->getName();
    $nickname = $userData->getGivenName();
    $email = $userData->getEmail();
    $avatar = $userData->getPicture();

    echo "Name: $name<br>";
    echo "Nickname: $nickname<br>";
    echo "Email: $email<br>";
    echo "Avatar: <img src=\"$avatar\">";
} catch (Google\Service\Exception $e) {
    header("Location: /authorization/login.php");
    exit;
}