 package org.roshkam.webparadiserp;

 import org.bukkit.ChatColor;
 import org.bukkit.command.Command;
 import org.bukkit.command.CommandSender;
 import org.bukkit.entity.Player;
 import org.bukkit.plugin.java.JavaPlugin;

 import java.awt.Desktop;
 import java.io.BufferedReader;
 import java.io.IOException;
 import java.io.InputStreamReader;
 import java.net.HttpURLConnection;
 import java.net.URI;
 import java.net.URISyntaxException;
 import java.net.URL;
 import java.net.URLEncoder;

    public class WebParadiseRP extends JavaPlugin {

        @Override
        public void onEnable() {
            getLogger().info("Реферальная система запущена");
        }

        @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
            if (label.equalsIgnoreCase("paradiserp")) {
                if (args.length >= 1) {
                    if (args[0].equalsIgnoreCase("confirm")) {
                        if (args.length >= 2) {
                            String uniqueCode = args[1];

                            sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");

                            if (sender instanceof Player) {
                                Player player = (Player) sender;
                                String playerName = player.getName();
                                String requestUrl;
                                try {
                                    requestUrl = "http://www.izuminka.com/authorization/server/confirm.php"
                                            + "?from=minecraft&code=" + URLEncoder.encode(uniqueCode, "UTF-8")
                                            + "&player=" + URLEncoder.encode(playerName, "UTF-8");
                                    String response = sendGetRequest(requestUrl);
                                    player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                                } catch (IOException e) {
                                    player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                                    e.printStackTrace();
                                }
                            } else {
                                sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                            }
                            return true;
                        } else {
                            sender.sendMessage(ChatColor.RED + "Использование: /paradiserp confirm [код]");
                        }
                    } else if (args[0].equalsIgnoreCase("set_nick")) {
                        if (args.length >= 3) {
                            String username = args[1];
                            String password = args[2];

                            sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");

                        if (sender instanceof Player) {
                            Player player = (Player) sender;
                            String playerName = player.getName();
                            String requestUrl;
                            try {
                                requestUrl = "http://www.izuminka.com/authorization/server/set_nick.php"
                                        + "?from=minecraft&player=" + URLEncoder.encode(playerName, "UTF-8")
                                        + "&username=" + URLEncoder.encode(username, "UTF-8")
                                        + "&password=" + URLEncoder.encode(password, "UTF-8");
                                String response = sendGetRequest(requestUrl);
                                player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                            } catch (IOException e) {
                                player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                                e.printStackTrace();
                            }
                        } else {
                            sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                        }
                            return true;
                        } else {
                            sender.sendMessage(ChatColor.RED + "Использование: /paradiserp set_nick [ваш логин от сайта] [ваш пароль от сайта]");
                        }
                    } else if (args[0].equalsIgnoreCase("apply_nick")) {
                        if (args.length >= 2) {
                            String applyCode = args[1];

                            sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");

                            if (sender instanceof Player) {
                                Player player = (Player) sender;
                                String playerName = player.getName();
                                String requestUrl;
                                try {
                                    requestUrl = "http://www.izuminka.com/authorization/server/set_nick.php"
                                            + "?from=minecraft&apply=1&code=" + URLEncoder.encode(applyCode, "UTF-8")
                                            + "&player=" + URLEncoder.encode(playerName, "UTF-8");
                                    String response = sendGetRequest(requestUrl);
                                    player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                                } catch (IOException e) {
                                    player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                                    e.printStackTrace();
                                }
                            } else {
                                sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                            }
                            return true;
                        } else {
                            sender.sendMessage(ChatColor.RED + "Использование: /paradiserp apply_nick [код]");
                        }
                    } else if (args[0].equalsIgnoreCase("discard_nick")) {
                        if (args.length >= 2) {
                            String discardCode = args[1];

                            sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");

                            if (sender instanceof Player) {
                                Player player = (Player) sender;
                                String playerName = player.getName();
                                String requestUrl;
                                try {
                                    requestUrl = "http://www.izuminka.com/authorization/server/set_nick.php"
                                            + "?from=minecraft&discard=1&code=" + URLEncoder.encode(discardCode, "UTF-8")
                                            + "&player=" + URLEncoder.encode(playerName, "UTF-8");
                                    String response = sendGetRequest(requestUrl);
                                    player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                                } catch (IOException e) {
                                    player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                                    e.printStackTrace();
                                }
                            } else {
                                sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                            }
                            return true;
                        } else {
                            sender.sendMessage(ChatColor.RED + "Использование: /paradiserp discard_nick [код]");
                        }
                    } else if (args[0].equalsIgnoreCase("web")) {
                        if (args[1].equalsIgnoreCase("give_prize")) {
                    sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");

                    if (sender instanceof Player) {
                        Player player = (Player) sender;
                        try {
                            Desktop.getDesktop().browse(new URI("http://www.izuminka.com/authorization/login.php?action=give_prize"));
                            player.sendMessage(ChatColor.GREEN + "Открыта ссылка в браузере.");
                        } catch (URISyntaxException | IOException e) {
                            player.sendMessage(ChatColor.RED + "Ошибка при открытии ссылки в браузере");
                            e.printStackTrace();
                        }
                    } else {
                        sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                    }
                    return true;
                } else {
                    sender.sendMessage(ChatColor.RED + "Использование: /paradiserp give_prize");
                    return true;
                }
                    } else if (args[0].equalsIgnoreCase("masterpass")) {
                        if (args[1].equalsIgnoreCase("create")) {
                            if (args.length > 3) {
                                String master = args[2];
                                String password = args[3];

                                sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");

                                if (sender instanceof Player) {
                                    Player player = (Player) sender;
                                    String playerName = player.getName();
                                    String requestUrl;
                                    try {
                                        requestUrl = "http://www.izuminka.com/authorization/server/create_masterpassword.php"
                                                + "?from=minecraft&master=" + URLEncoder.encode(master, "UTF-8")
                                                + "&player=" + URLEncoder.encode(playerName, "UTF-8")
                                                + "&password=" + URLEncoder.encode(password, "UTF-8");
                                        String response = sendGetRequest(requestUrl);
                                        player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                                    } catch (IOException e) {
                                        player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                                        e.printStackTrace();
                                    }
                                } else {
                                    sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                                }

                                return true;
                            } else {
                                sender.sendMessage(ChatColor.RED + "Использование: /paradiserp masterpass create [придумайте Master Password] [пароль от сайта]");
                                return true;
                            }
                        } else {
                            sender.sendMessage(ChatColor.RED + "Использование: /paradiserp masterpass create [придумайте Master Password] [пароль от сайта]");
                            return true;
                        }
                    } else if (args[0].equalsIgnoreCase("help")) {
                        sender.sendMessage(ChatColor.GREEN + "/referal get [код] - получение вознаграждения за приглашение");
                        sender.sendMessage(ChatColor.GREEN + "/referal referals - отобразить приглашенных пользователей");
                        sender.sendMessage(ChatColor.GREEN + "/referal my - отобразить ваш реферальный код");
                        sender.sendMessage(ChatColor.GREEN + "/referal help - помощь по плагину");
                        return true;
                    } else {
                        sender.sendMessage(ChatColor.RED + "Неверная команда");
                        return true;
                    }
                } else {
                    sender.sendMessage(ChatColor.RED + "Использование: /referal [get/referals/my/help]");
                    return true;
                }
            }
            return false;
        }

        private String sendGetRequest(String requestUrl) throws IOException {
            URL url = new URL(requestUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("GET");
            int responseCode = connection.getResponseCode();

            StringBuilder response = new StringBuilder();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStreamReader inputStreamReader = new InputStreamReader(connection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String line;

                while ((line = bufferedReader.readLine()) != null) {
                    response.append(line);
                }

                bufferedReader.close();
            } else {
                getLogger().warning("Ошибка " + responseCode + " при отправке данных на сервер");
            }

            connection.disconnect();

            return response.toString();
        }
    }
    