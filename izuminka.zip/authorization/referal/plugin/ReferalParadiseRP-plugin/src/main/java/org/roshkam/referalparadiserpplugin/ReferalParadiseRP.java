 package org.roshkam.referalparadiserpplugin;

 import org.bukkit.ChatColor;
 import org.bukkit.command.Command;
 import org.bukkit.command.CommandSender;
 import org.bukkit.entity.Player;
 import org.bukkit.plugin.java.JavaPlugin;

 import java.io.BufferedReader;
 import java.io.IOException;
 import java.io.InputStreamReader;
 import java.net.HttpURLConnection;
 import java.net.URL;
 import java.net.URLEncoder;

 public class ReferalParadiseRP extends JavaPlugin {

     @Override
     public void onEnable() {
         getLogger().info("Реферальная система запущена");
     }

     @Override
     public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
         if (label.equalsIgnoreCase("referal")) {
             if (args.length >= 1) {
                 if (args[0].equalsIgnoreCase("get")) {
                     if (args.length >= 2) {
                         String uniqueCode = args[1];

                         sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");

                         if (sender instanceof Player) {
                             Player player = (Player) sender;
                             String playerName = player.getName();
                             String requestUrl;
                             try {
                                 requestUrl = "http://www.izuminka.com/authorization/referal/get_prize.php"
                                         + "?from=minecraft&code=" + URLEncoder.encode(uniqueCode, "UTF-8")
                                         + "&player=" + URLEncoder.encode(playerName, "UTF-8");
                                 String response = sendGetRequest(requestUrl);
                                 player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                             } catch (IOException e) {
                                 player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                                 e.printStackTrace();
                             }
                         } else {
                             sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                         }
                         return true;
                     } else {
                         sender.sendMessage(ChatColor.RED + "Использование: /referal get [код]");
                     }
                 } else if (args[0].equalsIgnoreCase("referals")) {
                     sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");
                     if (sender instanceof Player) {
                         Player player = (Player) sender;
                         String playerName = player.getName();
                         String requestUrl;
                         try {
                             requestUrl = "http://www.izuminka.com/authorization/referal/referals.php"
                                     + "?from=minecraft&player=" + URLEncoder.encode(playerName, "UTF-8");
                             String response = sendGetRequest(requestUrl);
                             player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                         } catch (IOException e) {
                             player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                             e.printStackTrace();
                         }
                     } else {
                         sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                     }
                     return true;
                 } else if (args[0].equalsIgnoreCase("my")) {
                     sender.sendMessage(ChatColor.YELLOW + "Обработка, подождите...");
                     if (sender instanceof Player) {
                         Player player = (Player) sender;
                         String playerName = player.getName();
                         String requestUrl;
                         try {
                             requestUrl = "http://www.izuminka.com/authorization/referal/my_referal.php"
                                     + "?from=minecraft&player=" + URLEncoder.encode(playerName, "UTF-8");
                             String response = sendGetRequest(requestUrl);
                             player.sendMessage(ChatColor.GREEN + "ReferalSystem: " + response);
                         } catch (IOException e) {
                             player.sendMessage(ChatColor.RED + "Ошибка при отправке данных на сервер");
                             e.printStackTrace();
                         }
                     } else {
                         sender.sendMessage(ChatColor.RED + "Команду можно использовать только в игре");
                     }
                     return true;
                 } else if (args[0].equalsIgnoreCase("help")) {
                     sender.sendMessage(ChatColor.GREEN + "/referal get [код] - получение вознаграждения за приглашение");
                     sender.sendMessage(ChatColor.GREEN + "/referal referals - отобразить приглашенных пользователей");
                     sender.sendMessage(ChatColor.GREEN + "/referal my - отобразить ваш реферальный код");
                     sender.sendMessage(ChatColor.GREEN + "/referal help - помощь по плагину");
                     return true;
                 } else {
                     sender.sendMessage(ChatColor.RED + "Неверная команда");
                     return true;
                 }
             } else {
                 sender.sendMessage(ChatColor.RED + "Использование: /referal [get/referals/my/help]");
                 return true;
             }
         }
         return false;
     }

     private String sendGetRequest(String requestUrl) throws IOException {
         URL url = new URL(requestUrl);
         HttpURLConnection connection = (HttpURLConnection) url.openConnection();

         connection.setRequestMethod("GET");
         int responseCode = connection.getResponseCode();

         StringBuilder response = new StringBuilder();
         if (responseCode == HttpURLConnection.HTTP_OK) {
             InputStreamReader inputStreamReader = new InputStreamReader(connection.getInputStream());
             BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
             String line;

             while ((line = bufferedReader.readLine()) != null) {
                 response.append(line);
             }

             bufferedReader.close();
         } else {
             getLogger().warning("Ошибка " + responseCode + " при отправке данных на сервер");
         }

         connection.disconnect();

         return response.toString();
     }
 }