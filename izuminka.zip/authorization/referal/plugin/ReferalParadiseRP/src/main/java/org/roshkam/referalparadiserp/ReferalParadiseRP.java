package org.roshkam.referalparadiserp;

import org.bukkit.plugin.java.JavaPlugin;

public final class ReferalParadiseRP extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
