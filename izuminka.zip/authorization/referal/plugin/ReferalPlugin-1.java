package com.example.referalplugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class ReferalPlugin extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        getLogger().info("Реферальная система запущена");
        getCommand("referal").setExecutor(this);
    }

    @Override
    public void onDisable() {
        getLogger().info("Реферальная система отключена");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("referal")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "Эта команда доступна только игрокам.");
                return true;
            }

            Player player = (Player) sender;
            if (args.length < 2) {
                player.sendMessage(ChatColor.RED + "Необходимо указать уникальный код.");
                return true;
            }

            String uniqueCode = args[1];
            
            player.sendMessage(ChatColor.GREEN + "Обработка, подождите...");

            // Отправка GET-запроса
            try {
                String playerName = URLEncoder.encode(player.getName(), "UTF-8");
                String urlParameters = "code=" + uniqueCode + "&player=" + playerName;
                String requestUrl = "http://www.izuminka.com/referal/give_prize.php?" + urlParameters;

                URL url = new URL(requestUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = reader.readLine()) != null) {
                    response.append(inputLine);
                }

                reader.close();

                player.sendMessage(ChatColor.GOLD + "Запрос успешно отправлен.");
                player.sendMessage(ChatColor.GOLD + "Ответ с сервера: " + response.toString());
            } catch (Exception e) {
                player.sendMessage(ChatColor.RED + "Произошла ошибка при отправке запроса.");
                e.printStackTrace();
            }

            return true;
        }

        return false;
    }
}