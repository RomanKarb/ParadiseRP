<?php
echo $_POST['login'];
echo $_POST['password'];
echo "hhhhhh";
?>