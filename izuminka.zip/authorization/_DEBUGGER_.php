<?php
file_put_contents('debug_log.txt', 'DEBUGGER MODE - ON', FILE_APPEND);
echo "12332321323213213";
header ("Location: logiwn.php");
?>